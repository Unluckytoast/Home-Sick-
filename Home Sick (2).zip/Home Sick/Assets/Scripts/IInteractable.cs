// This interface is used by anything the player can interact with.
public interface IInteractable
{
    // Runs when the player uses the object.
    void Interact(Player player);

    // Returns the text shown to the player.
    string GetInteractText();

    // Runs when the player starts looking at the object.
    void OnFocus();

    // Runs when the player stops looking at the object.
    void OnLoseFocus();
}