using UnityEngine;

// This script opens the inventory and puts picked-up items into free slots.
public class InventoryManager : MonoBehaviour
{
    // The inventory UI root object.
    public GameObject inventoryMenu;

    // Tracks whether the inventory is open.
    private bool inventoryActive;

    // All available item slots in the inventory.
    public ItemsSlot[] itemsSlots;

    // Finds slot components automatically if none were assigned.
    private void Awake()
    {
        if (itemsSlots == null || itemsSlots.Length == 0)
        {
            itemsSlots = GetComponentsInChildren<ItemsSlot>(true);
        }
    }

    // Opens or closes the inventory when the input is pressed.
    private void Update()
    {
        if (!Input.GetButtonDown("Inventory"))
        {
            return;
        }

        inventoryActive = !inventoryActive;
        Time.timeScale = inventoryActive ? 0f : 1f;

        if (inventoryMenu != null)
        {
            inventoryMenu.SetActive(inventoryActive);
        }
    }

    // Adds an item to the first empty slot.
    public void AddItem(string itemName, int quantity, Sprite itemIcon)
    {
        for (int i = 0; i < itemsSlots.Length; i++)
        {
            if (itemsSlots[i] == null)
            {
                continue;
            }

            if (!itemsSlots[i].isFull)
            {
                itemsSlots[i].AddItem(itemName, quantity, itemIcon);
                return;
            }
        }
    }

    // Removes an item quantity from inventory if available.
    public bool TryConsumeItem(string itemName, int amount)
    {
        if (string.IsNullOrWhiteSpace(itemName) || amount <= 0)
        {
            return false;
        }

        for (int i = 0; i < itemsSlots.Length; i++)
        {
            if (itemsSlots[i] == null)
            {
                continue;
            }

            if (itemsSlots[i].TryConsume(itemName, amount))
            {
                return true;
            }
        }

        return false;
    }

}
