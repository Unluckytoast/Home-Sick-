using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class Item : MonoBehaviour
{
    [SerializeField]
    private string itemName;
    [SerializeField]
    private string description;
    
    [SerializeField]
     private Sprite icon;

    // This method can be called when the player interacts with the item
   
}