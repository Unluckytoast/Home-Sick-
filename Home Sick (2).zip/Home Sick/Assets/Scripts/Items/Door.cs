using UnityEngine;

// This script opens and closes a door when the player interacts with it.
public class Door : MonoBehaviour, IInteractable
{
    [Header("Door Setup")]

    // The part of the door that rotates.
    [SerializeField] private Transform doorPivot;

    // The rotation used when the door is closed.
    [SerializeField] private Vector3 closedRotation = Vector3.zero;

    // The rotation used when the door is open.
    [SerializeField] private Vector3 openRotation = new Vector3(0f, 100f, 0f);

    // How fast the door rotates.
    [SerializeField] private float rotationSpeed = 180f;

    [Header("Prompt")]

    // The text shown when the door is closed.
    [SerializeField] private string openText = "Open Door";

    // The text shown when the door is open.
    [SerializeField] private string closeText = "Close Door";

    // Tracks whether the door is open.
    private bool isOpen;

    // The rotation the door is moving toward.
    private Quaternion targetRotation;

    // Sets up the starting door rotation.
    private void Awake()
    {
        if (doorPivot == null)
        {
            doorPivot = transform;
        }

        doorPivot.localRotation = Quaternion.Euler(closedRotation);
        targetRotation = doorPivot.localRotation;
    }

    // Smoothly rotates the door toward its target rotation.
    private void Update()
    {
        if (doorPivot == null)
        {
            return;
        }

        doorPivot.localRotation = Quaternion.RotateTowards(
            doorPivot.localRotation,
            targetRotation,
            rotationSpeed * Time.deltaTime
        );
    }

    // Changes the door between open and closed.
    public void Interact(Player player)
    {
        isOpen = !isOpen;
        targetRotation = Quaternion.Euler(isOpen ? openRotation : closedRotation);
    }

    // Returns the correct prompt for the current door state.
    public string GetInteractText()
    {
        return isOpen ? closeText : openText;
    }

    // This door does nothing when focused.
    public void OnFocus() { }

    // This door does nothing when focus is lost.
    public void OnLoseFocus() { }
}
