using TMPro;
using UnityEngine;

// Attach to any object the player can examine (paintings, notes, etc.)
// Press E to open the message. Walking away closes it automatically.
public class ExamineInteractable : MonoBehaviour, IInteractable
{
    [Header("Prompt")]
    [SerializeField] private string examinePrompt = "Examine";

    [Header("Message")]
    [SerializeField] private string message = "It's nothing special.";
    [SerializeField] private GameObject messagePanel;
    [SerializeField] private TextMeshProUGUI messageText;

    private bool isOpen = false;

    private void Start()
    {
        if (messagePanel != null) messagePanel.SetActive(false);
    }

    public void Interact(Player player)
    {
        if (isOpen)
            CloseMessage();
        else
            OpenMessage();
    }

    // Only show prompt when closed — prevents E getting swallowed trying to "close"
    public string GetInteractText() => isOpen ? string.Empty : examinePrompt + " [E]";

    public void OnFocus() { }

    public void OnLoseFocus()
    {
        // Always close and restore cursor when player walks away
        ForceClose();
    }

    private void OpenMessage()
    {
        if (messagePanel == null)
        {
            Debug.LogWarning("[ExamineInteractable] messagePanel not assigned on " + gameObject.name);
            return;
        }

        isOpen = true;
        if (messageText != null) messageText.text = message;
        messagePanel.SetActive(true);
        Cursor.visible = true;
        Cursor.lockState = CursorLockMode.None;
    }

    private void CloseMessage()
    {
        if (!isOpen) return;
        ForceClose();
    }

    private void ForceClose()
    {
        isOpen = false;
        if (messagePanel != null) messagePanel.SetActive(false);
        Cursor.visible = false;
        Cursor.lockState = CursorLockMode.Locked;
    }

    private void OnDisable()
    {
        // Safety net — if object is disabled while open, restore cursor
        if (isOpen) ForceClose();
    }
}

