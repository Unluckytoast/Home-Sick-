using UnityEngine;
using UnityEngine.UI;

// This script shows and hides the interaction prompt on screen.
public class InteractionPromptUI : MonoBehaviour
{
    // The object that contains the prompt UI.
    [SerializeField] private GameObject promptRoot;

    // The text used to display the prompt message.
    [SerializeField] private Text promptText;

    // The format used to combine the key and action text.
    [SerializeField] private string promptFormat = "[{0}] {1}";

    // Sets a default prompt root if one was not assigned.
    private void Reset()
    {
        if (promptRoot == null)
        {
            promptRoot = gameObject;
        }
    }

    // Shows the prompt with the current action text.
    public void SetPrompt(string actionText, KeyCode key)
    {
        if (promptRoot != null)
        {
            promptRoot.SetActive(true);
        }

        if (promptText != null)
        {
            promptText.text = string.Format(promptFormat, key, actionText);
        }
    }

    // Hides the prompt.
    public void Hide()
    {
        if (promptRoot != null)
        {
            promptRoot.SetActive(false);
        }
    }
}
