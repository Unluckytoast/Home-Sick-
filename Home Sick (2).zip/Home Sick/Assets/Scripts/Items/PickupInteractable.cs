using UnityEngine;
using UnityEngine.Events;

// This script lets the player pick up an item and send it to the inventory.
public class PickupInteractable : MonoBehaviour, IInteractable
{
    // The item name shown in the inventory.
    [SerializeField] private string itemName = "Item";

    // How many of the item are picked up.
    [SerializeField] private int quantity = 1;

    // The icon shown for the item.
    [SerializeField] private Sprite itemIcon;   

    // The prompt shown to the player.
    [SerializeField] private string pickupText = "Pick Up";

    // Decides whether the object is destroyed after pickup.
    [SerializeField] private bool destroyOnPickup = true;

    // Extra events that run after the item is picked up.
    [SerializeField] private UnityEvent onPickedUp;

    // The inventory manager found in the scene.
    private InventoryManager inventoryManager;

    // Finds the inventory manager in the scene.
    private void Awake()
    {
        inventoryManager = FindFirstObjectByType<InventoryManager>();
    }

    // Gives the item to the inventory and removes it from the world.
    public void Interact(Player player)
    {
        if (inventoryManager != null)
        {
            inventoryManager.AddItem(itemName, quantity, itemIcon);
        }

        onPickedUp?.Invoke();

        if (destroyOnPickup)
        {
            Destroy(gameObject);
        }
        else
        {
            gameObject.SetActive(false);
        }
    }

    // Returns the pickup text shown in the interaction prompt.
    public string GetInteractText()
    {
        return pickupText + " " + itemName;
    }

    // This item does nothing when focused.
    public void OnFocus() { }

    // This item does nothing when focus is lost.
    public void OnLoseFocus() { }
}
