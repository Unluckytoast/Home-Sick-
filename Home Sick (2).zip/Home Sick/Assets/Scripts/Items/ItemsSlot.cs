using UnityEngine;
using UnityEngine.UI;
using TMPro;

// This script stores one inventory slot and updates its UI.
public class ItemsSlot : MonoBehaviour
{
    // The name of the item in this slot.
    public string itemName;

    // How many of this item the slot contains.
    public int quantity;

    // The icon shown for the item.
    public Sprite itemIcon;

    // Tracks whether this slot is already being used.
    public bool isFull;



    // The text that shows the item quantity.
    [SerializeField]
    private TMP_Text quanityText; 

    // The image that shows the item icon.
    [SerializeField]
    private Image itemIconImage;

    // Runs when the object first loads.
    private void Awake()
    {
        EnsureReferences();
    }

    // Runs in the editor when values change.
    private void OnValidate()
    {
        EnsureReferences();
    }

    // Finds missing UI references automatically.
    private void EnsureReferences()
    {
        // Find which slot component this is on the object.
        int slotIndex = GetSlotIndex();

        // Find the matching quantity text if it was not assigned.
        if (quanityText == null)
        {
            TMP_Text[] texts = GetComponentsInChildren<TMP_Text>(true);
            if (texts.Length > 0)
            {
                quanityText = texts[Mathf.Clamp(slotIndex, 0, texts.Length - 1)];
            }
        }

        // Find the matching item image if it was not assigned.
        if (itemIconImage == null)
        {
            Image[] images = GetComponentsInChildren<Image>(true);
            int imageIndex = 0;

            for (int i = 0; i < images.Length; i++)
            {
                if (images[i] == null || images[i].gameObject == gameObject)
                {
                    continue;
                }

                // Only use child images named ItemImage for slot icons.
                if (images[i].gameObject.name != "ItemImage")
                {
                    continue;
                }

                if (imageIndex == slotIndex)
                {
                    itemIconImage = images[i];
                    break;
                }

                imageIndex++;
            }

            // If no named image was found, fall back to the first child image.
            if (itemIconImage == null)
            {
                for (int i = 0; i < images.Length; i++)
                {
                    if (images[i] != null && images[i].gameObject != gameObject)
                    {
                        itemIconImage = images[i];
                        break;
                    }
                }
            }
        }
    }

    // Returns this component's position among sibling ItemsSlot components.
    private int GetSlotIndex()
    {
        ItemsSlot[] siblingSlots = GetComponents<ItemsSlot>();
        for (int i = 0; i < siblingSlots.Length; i++)
        {
            if (siblingSlots[i] == this)
            {
                return i;
            }
        }

        return 0;
    }
    
    // Fills the slot with item data and updates the UI.
    public void AddItem(string itemName, int quantity, Sprite itemIcon)
    {
        // Make sure the UI references exist before updating them.
        EnsureReferences();

        // Save the item data in this slot.
        this.itemName = itemName;
        this.quantity = quantity;
        this.itemIcon = itemIcon;
        isFull = true;

        // Show the quantity text if it exists.
        if (quanityText != null)
        {
            quanityText.text = quantity.ToString();
            quanityText.enabled = true;
        }

        // Show the item icon if the image exists.
        if (itemIconImage != null)
        {
            itemIconImage.sprite = itemIcon;
            itemIconImage.enabled = itemIcon != null;
        }
    }

    // Tries to remove a quantity from this slot if it contains the item.
    public bool TryConsume(string requestedItemName, int amount)
    {
        if (!isFull || amount <= 0)
        {
            return false;
        }

        if (!string.Equals(itemName, requestedItemName, System.StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }

        if (quantity < amount)
        {
            return false;
        }

        quantity -= amount;

        if (quantity <= 0)
        {
            ClearSlot();
            return true;
        }

        if (quanityText != null)
        {
            quanityText.text = quantity.ToString();
            quanityText.enabled = true;
        }

        return true;
    }

    private void ClearSlot()
    {
        itemName = string.Empty;
        quantity = 0;
        itemIcon = null;
        isFull = false;

        if (quanityText != null)
        {
            quanityText.text = string.Empty;
            quanityText.enabled = false;
        }

        if (itemIconImage != null)
        {
            itemIconImage.sprite = null;
            itemIconImage.enabled = false;
        }
    }
}
