using Unity.Cinemachine;
using UnityEngine;

[RequireComponent(typeof(Collider))]
public class CamSwitcher : MonoBehaviour
{
	// Tracks the last camera that was enabled by any trigger.
	private static CinemachineVirtualCameraBase lastCamera;

	// The tag that can trigger the camera change.
	[SerializeField] private string triggeringTag = "Player";

	// The camera this trigger should activate.
	[SerializeField] private CinemachineVirtualCameraBase activeCamera;

	// Makes the collider a trigger when the component is added or reset.
	private void Reset()
	{
		Collider col = GetComponent<Collider>();
		col.isTrigger = true;
	}

	// Makes sure the collider behaves like a trigger at runtime.
	private void Awake()
	{
		Collider col = GetComponent<Collider>();
		if (!col.isTrigger)
		{
			col.isTrigger = true;
		}

		if (lastCamera == null && activeCamera != null && activeCamera.gameObject.activeSelf)
		{
			lastCamera = activeCamera;
		}
	}

	// Activates this trigger's camera and disables the previously active one.
	private void OnTriggerEnter(Collider other)
	{
		if (!other.CompareTag(triggeringTag) || activeCamera == null)
		{
			return;
		}

		if (lastCamera == activeCamera)
		{
			return;
		}

		if (lastCamera != null)
		{
			lastCamera.gameObject.SetActive(false);
		}

		activeCamera.gameObject.SetActive(true);
		lastCamera = activeCamera;
	}
}
