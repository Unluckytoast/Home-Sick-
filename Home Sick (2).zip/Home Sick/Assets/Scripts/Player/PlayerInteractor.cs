using UnityEngine;

// This script finds nearby interactable objects and lets the player use them.
[RequireComponent(typeof(Player))]
public class PlayerInteractor : MonoBehaviour
{
    [Header("Detection")]

    // How far the player can interact.
    [SerializeField] private float interactRange = 2f;

    // Which layers can contain interactable objects.
    [SerializeField] private LayerMask interactLayers = ~0;

    [Header("Input")]

    // The key used to interact.
    [SerializeField] private KeyCode interactKey = KeyCode.E;

    [Header("UI")]

    // The prompt UI shown when the player can interact.
    [SerializeField] private InteractionPromptUI promptUI;

    // Reused array for overlap checks.
    private readonly Collider[] overlapResults = new Collider[24];

    // The player component on this object.
    private Player player;

    // The object currently being targeted.
    private IInteractable currentInteractable;

    // Gets the player reference and hides the prompt.
    private void Awake()
    {
        player = GetComponent<Player>();
        if (promptUI != null)
        {
            promptUI.Hide();
        }
    }

    // Updates the current interactable and checks for input.
    private void Update()
    {
        UpdateCurrentInteractable();

        if (currentInteractable != null && Input.GetKeyDown(interactKey))
        {
            currentInteractable.Interact(player);
            UpdatePrompt();
        }
    }

    // Chooses the closest interactable object.
    private void UpdateCurrentInteractable()
    {
        IInteractable bestInteractable = FindClosestInteractable();

        if (ReferenceEquals(bestInteractable, currentInteractable))
        {
            return;
        }

        if (currentInteractable != null)
        {
            currentInteractable.OnLoseFocus();
        }

        currentInteractable = bestInteractable;

        if (currentInteractable != null)
        {
            currentInteractable.OnFocus();
        }

        UpdatePrompt();
    }

    // Searches for the nearest interactable object in range.
    private IInteractable FindClosestInteractable()
    {
        int hitCount = Physics.OverlapSphereNonAlloc(
            transform.position,
            interactRange,
            overlapResults,
            interactLayers,
            QueryTriggerInteraction.Collide
        );

        IInteractable closest = null;
        float closestDistance = float.MaxValue;

        for (int i = 0; i < hitCount; i++)
        {
            Collider hit = overlapResults[i];
            if (hit == null) continue;

            IInteractable interactable = hit.GetComponentInParent<IInteractable>();
            if (interactable == null) continue;

            MonoBehaviour interactableBehaviour = interactable as MonoBehaviour;
            if (interactableBehaviour == null) continue;

            float sqrDistance = (interactableBehaviour.transform.position - transform.position).sqrMagnitude;
            if (sqrDistance < closestDistance)
            {
                closestDistance = sqrDistance;
                closest = interactable;
            }
        }

        return closest;
    }

    // Updates the on-screen interaction prompt.
    private void UpdatePrompt()
    {
        if (promptUI == null)
        {
            return;
        }

        if (currentInteractable == null)
        {
            promptUI.Hide();
            return;
        }

        string interactText = currentInteractable.GetInteractText();
        if (string.IsNullOrWhiteSpace(interactText))
        {
            promptUI.Hide();
            return;
        }

        promptUI.SetPrompt(interactText, interactKey);
    }

    // Clears focus and hides the prompt when disabled.
    private void OnDisable()
    {
        if (currentInteractable != null)
        {
            currentInteractable.OnLoseFocus();
            currentInteractable = null;
        }

        if (promptUI != null)
        {
            promptUI.Hide();
        }
    }

    // Draws the interaction range in the editor.
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireSphere(transform.position, interactRange);
    }
}
