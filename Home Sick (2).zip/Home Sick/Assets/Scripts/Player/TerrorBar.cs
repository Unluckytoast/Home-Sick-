using UnityEngine;
using UnityEngine.UI;

// This script updates the terror slider UI.
[RequireComponent(typeof(Slider))]
public class TerrorBar : MonoBehaviour
{
    // The slider used to show terror.
    public Slider slider;

    // Sets the highest value the slider can show.
    private void Awake()
    {
        if (slider == null)
        {
            slider = GetComponent<Slider>();
        }
    }

    // Sets the slider maximum value.
    public void SetMaxTerror( int terror)
    {
        slider.maxValue = terror;
        slider.value = Mathf.Clamp(slider.value, slider.minValue, slider.maxValue);
    }

    // Sets the slider to the current terror value.
    public void SetTerror(int terror)
    {
        slider.value = terror;
    }
}
