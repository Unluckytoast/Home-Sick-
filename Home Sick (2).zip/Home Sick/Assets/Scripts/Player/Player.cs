using UnityEngine;

// This script handles player movement and the terror bar.
[RequireComponent(typeof(CharacterController))]
public class Player : MonoBehaviour
{
	// The UI bar that shows the player's terror level.
	public TerrorBar terrorBar;

	// The highest terror value the player can reach.
	public int maxTerror = 3;

	// The player's current terror value.
	public int currentTerror;

	// The controller used for movement.
	private CharacterController controller;

	// The player's forward and backward move speed.
	public float speed = 2.5f;

	// The player's turn speed.
	private float turnSpeed = 70f;

	// Sets up the player controller and terror bar.
	private void Start()
	{
		currentTerror = 0;
		controller = GetComponent<CharacterController>();

		if (terrorBar != null)
		{
			terrorBar.SetMaxTerror(maxTerror);
			terrorBar.SetTerror(currentTerror);
		}
	}

	// Moves and rotates the player each frame.
	private void Update()
	{
		if (controller == null)
		{
			return;
		}

		Vector3 movDir;

		transform.Rotate(0, Input.GetAxis("Horizontal") * turnSpeed * Time.deltaTime, 0);

		movDir = transform.forward * Input.GetAxis("Vertical") * speed;

		controller.Move(movDir * Time.deltaTime - Vector3.up * 0.1f);
	}

	// Changes the player's terror value and updates the UI.
	private void UpdateTerror(int terrorAmount)
	{
		currentTerror = Mathf.Clamp(currentTerror + terrorAmount, 0, maxTerror);

		if (terrorBar != null)
		{
			terrorBar.SetTerror(currentTerror);
		}
	}
}