using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;

public class SafePuzzle : MonoBehaviour, IInteractable
{
    [Header("Door")]
    [SerializeField] private Transform doorPivot;
    [SerializeField] private Vector3 openRotation = new Vector3(0f, -90f, 0f);
    [SerializeField] private float rotationSpeed = 90f;

    [Header("Keypad")]
    [SerializeField] private GameObject codePanel;
    [SerializeField] private TextMeshProUGUI codeDisplay;
    [SerializeField] private string correctCode = "1234";

    private string entered = "";
    private bool unlocked = false;
    private bool panelOpen = false;
    private Quaternion closedRot;
    private Quaternion openRot;

    private void Start()
    {
        // Store rotations from whatever the door pivot is at right now
        closedRot = doorPivot != null ? doorPivot.localRotation : Quaternion.identity;
        openRot   = Quaternion.Euler(openRotation);

        EnsureEventSystem();

        if (codePanel != null) codePanel.SetActive(false);
        if (codeDisplay != null) codeDisplay.text = "";
    }

    private void Update()
    {
        if (doorPivot == null) return;
        Quaternion target = unlocked ? openRot : closedRot;
        doorPivot.localRotation = Quaternion.RotateTowards(
            doorPivot.localRotation, target, rotationSpeed * Time.deltaTime);
    }

    // ── IInteractable ────────────────────────────────────────────
    public void Interact(Player player)
    {
        if (unlocked) return;
        Open();
    }

    public string GetInteractText() => unlocked ? "" : "Open Safe [E]";
    public void OnFocus()   { }
    public void OnLoseFocus() { if (panelOpen) Close(); }

    // ── Called by keypad buttons via OnClick ─────────────────────
    public void PressDigit(string digit)
    {
        if (!panelOpen || unlocked) return;

        entered += digit;
        codeDisplay.text = entered;

        if (entered.Length < 4) return;

        if (entered == correctCode)
        {
            unlocked = true;
            Close();
        }
        else
        {
            entered = "";
            codeDisplay.text = "";
        }
    }

    public void ClosePanel() => Close();

    // ── Helpers ──────────────────────────────────────────────────
    private void Open()
    {
        if (codePanel == null)
        {
            Debug.LogWarning("[SafePuzzle] codePanel is not assigned in Inspector.");
            return;
        }
        panelOpen = true;
        entered = "";
        codeDisplay.text = "";
        codePanel.SetActive(true);
        Cursor.visible   = true;
        Cursor.lockState = CursorLockMode.None;
    }

    private void Close()
    {
        panelOpen = false;
        entered   = "";
        if (codeDisplay != null) codeDisplay.text = "";
        if (codePanel   != null) codePanel.SetActive(false);
        Cursor.visible   = false;
        Cursor.lockState = CursorLockMode.Locked;
    }

    private static void EnsureEventSystem()
    {
        if (FindFirstObjectByType<EventSystem>() != null) return;
        var go = new GameObject("EventSystem");
        go.AddComponent<EventSystem>();
        go.AddComponent<StandaloneInputModule>();
    }
}

