using UnityEngine;
using UnityEngine.Events;

public class SconceBulbPuzzle : MonoBehaviour, IInteractable
{
    [SerializeField] private string requiredItemName = "Bulb";
    [SerializeField] private GameObject pathBlocker;
    [SerializeField] private Transform openingPivot;
    [SerializeField] private Vector3 openRotation = new Vector3(0f, -90f, 0f);
    [SerializeField] private float openingSpeed = 180f;
    [SerializeField] private Light sconceLight;
    [SerializeField] private UnityEvent onPuzzleSolved;

    private bool solved;
    private bool opening;
    private InventoryManager inventory;
    private Quaternion targetRotation;

    private void Awake()
    {
        inventory = FindFirstObjectByType<InventoryManager>();

        if (openingPivot == null && pathBlocker != null)
        {
            openingPivot = pathBlocker.transform;
        }

        if (openingPivot != null)
        {
            targetRotation = openingPivot.localRotation;
        }
    }

    private void Update()
    {
        if (!opening || openingPivot == null)
        {
            return;
        }

        openingPivot.localRotation = Quaternion.RotateTowards(
            openingPivot.localRotation,
            targetRotation,
            openingSpeed * Time.deltaTime
        );
    }

    public void Interact(Player player)
    {
        if (solved || inventory == null)
        {
            return;
        }

        if (!inventory.TryConsumeItem(requiredItemName, 1))
        {
            return;
        }

        solved = true;

        if (openingPivot != null)
        {
            targetRotation = Quaternion.Euler(openRotation);
            opening = true;
        }

        if (sconceLight != null)
        {
            sconceLight.enabled = true;
        }

        onPuzzleSolved?.Invoke();
    }

    public string GetInteractText()
    {
        return solved ? "The sconce is already lit." : $"Insert {requiredItemName}";
    }

    public void OnFocus() { }
    public void OnLoseFocus() { }
}
